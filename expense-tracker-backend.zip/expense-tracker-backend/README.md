# Expense Tracker Backend

Backend API for the Expense Tracker full-stack project.

## Tech stack

- Node.js
- Express.js
- MongoDB
- Mongoose
- JWT authentication
- bcryptjs
- CORS

## Folder structure

```text
backend/
├── middleware/
│   ├── authMiddleware.js
│   └── errorMiddleware.js
├── models/
│   ├── Expense.js
│   └── User.js
├── routes/
│   ├── authRoutes.js
│   └── expenseRoutes.js
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Setup

1. Install Node.js.
2. Create a MongoDB database.
3. Copy `.env.example` to `.env`.
4. Put your MongoDB connection string in `MONGO_URI`.
5. Create a strong value for `JWT_SECRET`.
6. Run:

```bash
npm install
npm run dev
```

The API runs on:

`http://localhost:5000`

## API endpoints

### Auth

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`

### Expenses

All expense endpoints require:

`Authorization: Bearer YOUR_TOKEN`

- `GET /api/expenses`
- `POST /api/expenses`
- `GET /api/expenses/:id`
- `PUT /api/expenses/:id`
- `DELETE /api/expenses/:id`
- `DELETE /api/expenses`
- `GET /api/expenses/summary/overview`

## Important

Never upload your real `.env` file or MongoDB password to GitHub.
