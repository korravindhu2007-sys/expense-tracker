import express from "express";
import Expense from "../models/Expense.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.use(protect);

router.get("/", async (req, res) => {
  try {
    const expenses = await Expense.find({ user: req.user._id }).sort({
      date: -1,
      createdAt: -1
    });

    res.json({
      success: true,
      count: expenses.length,
      expenses
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch expenses."
    });
  }
});

router.post("/", async (req, res) => {
  try {
    const { title, amount, category, date, description } = req.body;

    if (!title || amount === undefined || !category) {
      return res.status(400).json({
        success: false,
        message: "Title, amount and category are required."
      });
    }

    const numericAmount = Number(amount);

    if (!Number.isFinite(numericAmount) || numericAmount < 0) {
      return res.status(400).json({
        success: false,
        message: "Amount must be a valid non-negative number."
      });
    }

    const expense = await Expense.create({
      user: req.user._id,
      title,
      amount: numericAmount,
      category,
      date: date || new Date(),
      description: description || ""
    });

    res.status(201).json({
      success: true,
      message: "Expense added successfully.",
      expense
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to add expense."
    });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!expense) {
      return res.status(404).json({
        success: false,
        message: "Expense not found."
      });
    }

    res.json({ success: true, expense });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Invalid expense ID."
    });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const { title, amount, category, date, description } = req.body;

    const expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!expense) {
      return res.status(404).json({
        success: false,
        message: "Expense not found."
      });
    }

    if (title !== undefined) expense.title = title;
    if (category !== undefined) expense.category = category;
    if (date !== undefined) expense.date = date;
    if (description !== undefined) expense.description = description;

    if (amount !== undefined) {
      const numericAmount = Number(amount);

      if (!Number.isFinite(numericAmount) || numericAmount < 0) {
        return res.status(400).json({
          success: false,
          message: "Amount must be a valid non-negative number."
        });
      }

      expense.amount = numericAmount;
    }

    await expense.save();

    res.json({
      success: true,
      message: "Expense updated successfully.",
      expense
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Failed to update expense."
    });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const expense = await Expense.findOneAndDelete({
      _id: req.params.id,
      user: req.user._id
    });

    if (!expense) {
      return res.status(404).json({
        success: false,
        message: "Expense not found."
      });
    }

    res.json({
      success: true,
      message: "Expense deleted successfully."
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Failed to delete expense."
    });
  }
});

router.delete("/", async (req, res) => {
  try {
    const result = await Expense.deleteMany({ user: req.user._id });

    res.json({
      success: true,
      message: `${result.deletedCount} expense(s) deleted.`
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to clear expenses."
    });
  }
});

router.get("/summary/overview", async (req, res) => {
  try {
    const expenses = await Expense.find({ user: req.user._id });

    const total = expenses.reduce((sum, item) => sum + item.amount, 0);

    const todayString = new Date().toISOString().slice(0, 10);
    const todayTotal = expenses
      .filter((item) => new Date(item.date).toISOString().slice(0, 10) === todayString)
      .reduce((sum, item) => sum + item.amount, 0);

    const byCategory = expenses.reduce((result, item) => {
      result[item.category] = (result[item.category] || 0) + item.amount;
      return result;
    }, {});

    res.json({
      success: true,
      summary: {
        total,
        todayTotal,
        count: expenses.length,
        byCategory
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to create expense summary."
    });
  }
});

export default router;
